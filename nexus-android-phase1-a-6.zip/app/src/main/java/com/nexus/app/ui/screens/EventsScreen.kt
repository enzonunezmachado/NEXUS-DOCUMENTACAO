package com.nexus.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ConfirmationNumber
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Directions
import androidx.compose.material.icons.outlined.Event
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.OpenInNew
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.nexus.app.core.DateTimeUtils
import com.nexus.app.data.db.entity.CategoryEntity
import com.nexus.app.data.db.entity.CreditCardEntity
import com.nexus.app.domain.model.EventLifecycleStatus
import com.nexus.app.domain.model.EventWithDetails
import com.nexus.app.domain.model.PaymentMethod
import com.nexus.app.domain.model.TicketStatus
import com.nexus.app.ui.components.ConfirmDangerDialog
import com.nexus.app.ui.components.NexusCard
import com.nexus.app.ui.components.NexusDatePickerDialog
import com.nexus.app.ui.components.NexusEmptyState
import com.nexus.app.ui.components.NexusTimePickerDialog
import com.nexus.app.ui.components.ReminderLeadTimeSelector
import com.nexus.app.ui.theme.LocalNexusPalette
import java.time.LocalDate
import java.time.LocalTime

@Composable
fun EventsScreen(
    events: List<EventWithDetails>,
    onOpenEvent: (String) -> Unit,
    onCreateEvent: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalNexusPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var filterMode by remember { mutableStateOf("UPCOMING") } // UPCOMING, ALL, PENDING_TICKET
    val todayStart = DateTimeUtils.localDateToStartOfDayEpoch(DateTimeUtils.todayLocalDate())

    val filtered = remember(events, searchQuery, filterMode) {
        val q = searchQuery.trim().lowercase()
        events.filter { item ->
            val ev = item.event
            val matchesMode = when (filterMode) {
                "UPCOMING" -> ev.endAt >= todayStart && ev.eventStatus != EventLifecycleStatus.CANCELLED
                "PENDING_TICKET" -> !ev.ticketStatus.isPaidOrBought && ev.ticketStatus != TicketStatus.FREE && ev.ticketStatus != TicketStatus.CANCELLED
                else -> true
            }
            val matchesQ = q.isEmpty() ||
                ev.name.lowercase().contains(q) ||
                ev.locationName.lowercase().contains(q) ||
                ev.city.lowercase().contains(q)
            matchesMode && matchesQ
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Eventos",
                    style = MaterialTheme.typography.headlineMedium,
                    color = palette.textPrimary
                )
                OutlinedButton(onClick = onCreateEvent, shape = RoundedCornerShape(10.dp)) {
                    Text("Novo evento", color = palette.textPrimary)
                }
            }
        }

        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar eventos por nome, local ou cidade") },
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Outlined.Close, contentDescription = "Limpar")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = filterMode == "UPCOMING",
                    onClick = { filterMode = "UPCOMING" },
                    label = { Text("Próximos") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.surfaceElevated,
                        selectedLabelColor = palette.highlight
                    )
                )
                FilterChip(
                    selected = filterMode == "PENDING_TICKET",
                    onClick = { filterMode = "PENDING_TICKET" },
                    label = { Text("Ingresso pendente") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.surfaceElevated,
                        selectedLabelColor = palette.highlight
                    )
                )
                FilterChip(
                    selected = filterMode == "ALL",
                    onClick = { filterMode = "ALL" },
                    label = { Text("Todos") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = palette.surfaceElevated,
                        selectedLabelColor = palette.highlight
                    )
                )
            }
        }

        if (filtered.isEmpty()) {
            item {
                NexusEmptyState(
                    icon = Icons.Outlined.Event,
                    title = "Nenhum evento encontrado",
                    subtitle = "Cadastre congressos, palestras, workshops ou encontros para acompanhar ingressos, custos e agenda.",
                    actionLabel = "Novo evento",
                    onAction = onCreateEvent
                )
            }
        } else {
            items(filtered, key = { it.event.id }) { ew ->
                EventSummaryCard(
                    item = ew,
                    onClick = { onOpenEvent(ew.event.id) }
                )
            }
        }
    }
}

@Composable
fun EventSummaryCard(
    item: EventWithDetails,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalNexusPalette.current
    val ev = item.event
    val dateLabel = if (ev.isAllDay) {
        "${DateTimeUtils.formatDate(ev.startAt)} · Dia inteiro"
    } else {
        "${DateTimeUtils.formatDate(ev.startAt)} · ${DateTimeUtils.formatTime(ev.startAt)}–${DateTimeUtils.formatTime(ev.endAt)}"
    }
    val placeText = listOf(ev.locationName, ev.city).filter { it.isNotBlank() }.joinToString(", ")

    NexusCard(
        modifier = modifier.fillMaxWidth(),
        elevated = true,
        onClick = onClick
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = ev.name,
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = ev.ticketStatus.label,
                style = MaterialTheme.typography.labelMedium,
                color = when (ev.ticketStatus) {
                    TicketStatus.PAID, TicketStatus.BOUGHT, TicketStatus.FREE -> palette.positive
                    TicketStatus.PENDING, TicketStatus.PARTIALLY_PAID, TicketStatus.NOT_BOUGHT -> palette.warning
                    TicketStatus.CANCELLED -> palette.danger
                }
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        val meta = buildList {
            add(dateLabel)
            if (placeText.isNotBlank()) add(placeText)
            item.category?.let { add(it.name) }
        }.joinToString(" · ")
        Text(text = meta, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)

        if (item.estimatedTotalCostCents > 0L || item.linkedTasks.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            val extra = buildList {
                if (item.estimatedTotalCostCents > 0L) {
                    add("Custo total: ${DateTimeUtils.formatBrl(item.estimatedTotalCostCents)}")
                    add("Pago: ${DateTimeUtils.formatBrl(item.paidTotalCostCents)}")
                }
                if (item.linkedTasks.isNotEmpty()) {
                    add("${item.linkedTasks.size} tarefa(s)")
                }
            }.joinToString(" · ")
            Text(text = extra, style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventEditorSheet(
    existingEvent: EventWithDetails?,
    categories: List<CategoryEntity>,
    creditCards: List<CreditCardEntity>,
    onDismiss: () -> Unit,
    onSave: (
        id: String?,
        name: String,
        description: String,
        categoryId: String?,
        startAt: Long,
        endAt: Long,
        isAllDay: Boolean,
        officialLink: String,
        ticketLink: String,
        locationName: String,
        address: String,
        city: String,
        state: String,
        notes: String,
        eventStatus: EventLifecycleStatus,
        ticketStatus: TicketStatus,
        ticketPriceCents: Long,
        ticketQuantity: Int,
        ticketFeesCents: Long,
        ticketPurchaseDate: Long?,
        ticketDueDate: Long?,
        paymentMethod: PaymentMethod,
        creditCardId: String?,
        installmentsCount: Int,
        reminderMinutesBefore: Int?
    ) -> Unit,
    onDelete: (String) -> Unit,
    onAddLinkedTask: (String) -> Unit,
    onOpenTask: (String) -> Unit,
    onAddAdditionalExpense: (String) -> Unit,
    onOpenTransaction: (String) -> Unit,
    onError: (String, Throwable) -> Unit
) {
    val palette = LocalNexusPalette.current
    val context = LocalContext.current
    val ev = existingEvent?.event

    var name by remember(ev?.id) { mutableStateOf(ev?.name ?: "") }
    var description by remember(ev?.id) { mutableStateOf(ev?.description ?: "") }
    var categoryId by remember(ev?.id) { mutableStateOf(ev?.categoryId) }
    var isAllDay by remember(ev?.id) { mutableStateOf(ev?.isAllDay ?: false) }
    var startDate by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.epochToLocalDate(it.startAt) } ?: DateTimeUtils.todayLocalDate())
    }
    var startTime by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.epochToLocalTime(it.startAt) } ?: LocalTime.of(19, 0))
    }
    var endDate by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.epochToLocalDate(it.endAt) } ?: DateTimeUtils.todayLocalDate())
    }
    var endTime by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.epochToLocalTime(it.endAt) } ?: LocalTime.of(21, 0))
    }

    var officialLink by remember(ev?.id) { mutableStateOf(ev?.officialLink ?: "") }
    var ticketLink by remember(ev?.id) { mutableStateOf(ev?.ticketLink ?: "") }
    var locationName by remember(ev?.id) { mutableStateOf(ev?.locationName ?: "") }
    var address by remember(ev?.id) { mutableStateOf(ev?.address ?: "") }
    var city by remember(ev?.id) { mutableStateOf(ev?.city ?: "") }
    var state by remember(ev?.id) { mutableStateOf(ev?.state ?: "") }
    var notes by remember(ev?.id) { mutableStateOf(ev?.notes ?: "") }

    var eventStatus by remember(ev?.id) { mutableStateOf(ev?.eventStatus ?: EventLifecycleStatus.PLANNED) }
    var ticketStatus by remember(ev?.id) { mutableStateOf(ev?.ticketStatus ?: TicketStatus.FREE) }
    var ticketPriceInput by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.centsToInputString(it.ticketPriceCents) } ?: "")
    }
    var ticketQtyInput by remember(ev?.id) { mutableStateOf((ev?.ticketQuantity ?: 1).toString()) }
    var ticketFeesInput by remember(ev?.id) {
        mutableStateOf(ev?.let { DateTimeUtils.centsToInputString(it.ticketFeesCents) } ?: "")
    }
    var ticketDueDate by remember(ev?.id) {
        mutableStateOf(ev?.ticketDueDate?.let { DateTimeUtils.epochToLocalDate(it) })
    }
    var paymentMethod by remember(ev?.id) { mutableStateOf(ev?.paymentMethod ?: PaymentMethod.PIX) }
    var creditCardId by remember(ev?.id) { mutableStateOf(ev?.creditCardId) }
    var installmentsInput by remember(ev?.id) { mutableStateOf((ev?.installmentsCount ?: 1).toString()) }

    var pickTarget by remember { mutableStateOf<String?>(null) }
    var showCategoryMenu by remember { mutableStateOf(false) }
    var showLifecycleMenu by remember { mutableStateOf(false) }
    var showTicketStatusMenu by remember { mutableStateOf(false) }
    var showPaymentMenu by remember { mutableStateOf(false) }
    var showCardMenu by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }
    var reminderMinutesBefore by remember(ev?.id) { mutableStateOf<Int?>(null) }

    val fullAddressText = listOf(locationName, address, city, state).filter { it.isNotBlank() }.joinToString(", ")

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = palette.surface,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (ev == null) "Novo evento" else "Detalhes do evento",
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.textPrimary
                )
                if (ev != null) {
                    IconButton(onClick = { showDeleteConfirm = true }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Excluir evento", tint = palette.danger)
                    }
                }
            }

            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    if (it.isNotBlank()) nameError = false
                },
                label = { Text("Nome do evento *") },
                isError = nameError,
                supportingText = if (nameError) {
                    { Text("Informe o nome do evento.") }
                } else null,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Descrição") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    val catName = categories.firstOrNull { it.id == categoryId }?.name ?: "Sem categoria"
                    OutlinedButton(
                        onClick = { showCategoryMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(catName, color = palette.textPrimary, maxLines = 1)
                    }
                    DropdownMenu(expanded = showCategoryMenu, onDismissRequest = { showCategoryMenu = false }) {
                        DropdownMenuItem(text = { Text("Sem categoria") }, onClick = {
                            categoryId = null; showCategoryMenu = false
                        })
                        categories.forEach { c ->
                            DropdownMenuItem(text = { Text(c.name) }, onClick = {
                                categoryId = c.id; showCategoryMenu = false
                            })
                        }
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    OutlinedButton(
                        onClick = { showLifecycleMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(eventStatus.label, color = palette.textPrimary, maxLines = 1)
                    }
                    DropdownMenu(expanded = showLifecycleMenu, onDismissRequest = { showLifecycleMenu = false }) {
                        EventLifecycleStatus.entries.forEach { st ->
                            DropdownMenuItem(text = { Text(st.label) }, onClick = {
                                eventStatus = st; showLifecycleMenu = false
                            })
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Dia inteiro", style = MaterialTheme.typography.bodyLarge, color = palette.textPrimary)
                Switch(checked = isAllDay, onCheckedChange = { isAllDay = it })
            }

            NexusCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Início", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickTarget = "startDate" }) {
                            Text(DateTimeUtils.formatDate(startDate), color = palette.textPrimary)
                        }
                        if (!isAllDay) {
                            OutlinedButton(onClick = { pickTarget = "startTime" }) {
                                Text(startTime.toString(), color = palette.textPrimary)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Término", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickTarget = "endDate" }) {
                            Text(DateTimeUtils.formatDate(endDate), color = palette.textPrimary)
                        }
                        if (!isAllDay) {
                            OutlinedButton(onClick = { pickTarget = "endTime" }) {
                                Text(endTime.toString(), color = palette.textPrimary)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                ReminderLeadTimeSelector(
                    selectedMinutes = reminderMinutesBefore,
                    onSelectMinutes = { reminderMinutesBefore = it }
                )
            }

            NexusCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.LocationOn, contentDescription = null, tint = palette.textSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Localização e Links", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = locationName,
                    onValueChange = { locationName = it },
                    label = { Text("Nome do local") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Endereço") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = city,
                        onValueChange = { city = it },
                        label = { Text("Cidade") },
                        modifier = Modifier.weight(2f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = state,
                        onValueChange = { state = it },
                        label = { Text("UF") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }
                if (fullAddressText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Prévia de mapa online indisponível offline. Endereço salvo localmente.",
                        style = MaterialTheme.typography.labelSmall,
                        color = palette.textSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            runCatching {
                                val uri = Uri.parse("geo:0,0?q=${Uri.encode(fullAddressText)}")
                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            }.onFailure { onError("Abrir Maps", it) }
                        }) {
                            Icon(Icons.Outlined.OpenInNew, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Google Maps")
                        }
                        OutlinedButton(onClick = {
                            runCatching {
                                val uri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=${Uri.encode(fullAddressText)}")
                                context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            }.onFailure { onError("Abrir Rota", it) }
                        }) {
                            Icon(Icons.Outlined.Directions, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Rota")
                        }
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = officialLink,
                    onValueChange = { officialLink = it },
                    label = { Text("Link oficial") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = ticketLink,
                    onValueChange = { ticketLink = it },
                    label = { Text("Link do ingresso") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }

            NexusCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.ConfirmationNumber, contentDescription = null, tint = palette.textSecondary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Ingresso e Financeiro", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Box {
                    OutlinedButton(
                        onClick = { showTicketStatusMenu = true },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Situação do ingresso: ${ticketStatus.label}", color = palette.textPrimary)
                    }
                    DropdownMenu(expanded = showTicketStatusMenu, onDismissRequest = { showTicketStatusMenu = false }) {
                        TicketStatus.entries.forEach { ts ->
                            DropdownMenuItem(text = { Text(ts.label) }, onClick = {
                                ticketStatus = ts; showTicketStatusMenu = false
                            })
                        }
                    }
                }

                if (ticketStatus == TicketStatus.FREE) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Evento gratuito não gera obrigação financeira nem lembrete de pagamento.",
                        style = MaterialTheme.typography.labelMedium,
                        color = palette.positive
                    )
                } else if (ticketStatus != TicketStatus.CANCELLED) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = ticketPriceInput,
                            onValueChange = { ticketPriceInput = it },
                            label = { Text("Preço (R$)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = ticketQtyInput,
                            onValueChange = { ticketQtyInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Qtd") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.7f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = ticketFeesInput,
                            onValueChange = { ticketFeesInput = it },
                            label = { Text("Taxas") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(
                                onClick = { showPaymentMenu = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text(paymentMethod.label, color = palette.textPrimary, maxLines = 1)
                            }
                            DropdownMenu(expanded = showPaymentMenu, onDismissRequest = { showPaymentMenu = false }) {
                                PaymentMethod.entries.forEach { pm ->
                                    DropdownMenuItem(text = { Text(pm.label) }, onClick = {
                                        paymentMethod = pm; showPaymentMenu = false
                                    })
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = { pickTarget = "ticketDueDate" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = ticketDueDate?.let { "Venc: ${DateTimeUtils.formatDate(it)}" } ?: "Limite pgto",
                                color = palette.textPrimary,
                                maxLines = 1
                            )
                        }
                    }

                    if (paymentMethod == PaymentMethod.CREDIT_CARD) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.weight(1.4f)) {
                                val cardName = creditCards.firstOrNull { it.id == creditCardId }?.name ?: "Selecionar cartão"
                                OutlinedButton(
                                    onClick = { showCardMenu = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(cardName, color = palette.textPrimary, maxLines = 1)
                                }
                                DropdownMenu(expanded = showCardMenu, onDismissRequest = { showCardMenu = false }) {
                                    DropdownMenuItem(text = { Text("Nenhum") }, onClick = {
                                        creditCardId = null; showCardMenu = false
                                    })
                                    creditCards.forEach { card ->
                                        DropdownMenuItem(text = { Text(card.name) }, onClick = {
                                            creditCardId = card.id; showCardMenu = false
                                        })
                                    }
                                }
                            }
                            OutlinedTextField(
                                value = installmentsInput,
                                onValueChange = { installmentsInput = it.filter { c -> c.isDigit() } },
                                label = { Text("Parcelas") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(0.8f),
                                singleLine = true
                            )
                        }
                    }
                }
            }

            if (existingEvent != null) {
                NexusCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Custos do evento", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                            Text(
                                text = "Estimado: ${DateTimeUtils.formatBrl(existingEvent.estimatedTotalCostCents)} · Pago: ${DateTimeUtils.formatBrl(existingEvent.paidTotalCostCents)}",
                                style = MaterialTheme.typography.labelMedium,
                                color = palette.textSecondary
                            )
                        }
                        OutlinedButton(onClick = { onAddAdditionalExpense(existingEvent.event.id) }) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Custo")
                        }
                    }
                    if (existingEvent.linkedTransactions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        existingEvent.linkedTransactions.forEach { txItem ->
                            val tx = txItem.transaction
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { onOpenTransaction(tx.id) }) {
                                    Text(
                                        text = "${tx.eventCostType?.label ?: "Despesa"}: ${tx.description}",
                                        color = palette.textPrimary
                                    )
                                }
                                Text(
                                    text = "${DateTimeUtils.formatBrl(tx.amountCents)} · ${tx.status.label}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = palette.textSecondary
                                )
                            }
                        }
                    }
                }

                NexusCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Tarefas do evento", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                        OutlinedButton(onClick = { onAddLinkedTask(existingEvent.event.id) }) {
                            Icon(Icons.Outlined.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Tarefa")
                        }
                    }
                    if (existingEvent.linkedTasks.isEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Nenhuma tarefa vinculada a este evento.", style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
                    } else {
                        existingEvent.linkedTasks.forEach { tw ->
                            TextButton(onClick = { onOpenTask(tw.task.id) }) {
                                Text("${tw.task.title} (${tw.task.status.label})", color = palette.textPrimary)
                            }
                        }
                    }
                }
            }

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Observações") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4
            )

            Button(
                onClick = {
                    if (name.isBlank()) {
                        nameError = true
                        return@Button
                    }
                    val startEpoch = if (isAllDay) {
                        DateTimeUtils.localDateToStartOfDayEpoch(startDate)
                    } else {
                        DateTimeUtils.localDateTimeToEpoch(startDate, startTime)
                    }
                    val normalizedEndDate = if (endDate < startDate) startDate else endDate
                    val endEpoch = if (isAllDay) {
                        DateTimeUtils.localDateToEndOfDayEpoch(normalizedEndDate)
                    } else {
                        DateTimeUtils.localDateTimeToEpoch(normalizedEndDate, endTime)
                    }
                    val priceCents = DateTimeUtils.parseBrlToCents(ticketPriceInput) ?: 0L
                    val feesCents = DateTimeUtils.parseBrlToCents(ticketFeesInput) ?: 0L
                    val qty = ticketQtyInput.toIntOrNull()?.coerceAtLeast(1) ?: 1
                    val instCount = installmentsInput.toIntOrNull()?.coerceAtLeast(1) ?: 1
                    val dueEpoch = ticketDueDate?.let { DateTimeUtils.localDateTimeToEpoch(it, LocalTime.of(12, 0)) }
                    val purchaseEpoch = if (ticketStatus.isPaidOrBought) {
                        ev?.ticketPurchaseDate ?: DateTimeUtils.nowEpochMillis()
                    } else null

                    onSave(
                        ev?.id,
                        name,
                        description,
                        categoryId,
                        startEpoch,
                        endEpoch,
                        isAllDay,
                        officialLink,
                        ticketLink,
                        locationName,
                        address,
                        city,
                        state,
                        notes,
                        eventStatus,
                        ticketStatus,
                        priceCents,
                        qty,
                        feesCents,
                        purchaseEpoch,
                        dueEpoch,
                        paymentMethod,
                        creditCardId,
                        instCount,
                        reminderMinutesBefore
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.highlight,
                    contentColor = palette.background
                )
            ) {
                Text("Salvar evento")
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    when (pickTarget) {
        "startDate" -> NexusDatePickerDialog(
            initialDate = startDate,
            onDateSelected = {
                startDate = it
                if (endDate < it) endDate = it
            },
            onDismiss = { pickTarget = null }
        )
        "endDate" -> NexusDatePickerDialog(
            initialDate = endDate,
            onDateSelected = { endDate = it },
            onDismiss = { pickTarget = null }
        )
        "startTime" -> NexusTimePickerDialog(
            initialTime = startTime,
            onTimeSelected = { startTime = it },
            onDismiss = { pickTarget = null }
        )
        "endTime" -> NexusTimePickerDialog(
            initialTime = endTime,
            onTimeSelected = { endTime = it },
            onDismiss = { pickTarget = null }
        )
        "ticketDueDate" -> NexusDatePickerDialog(
            initialDate = ticketDueDate ?: startDate,
            onDateSelected = { ticketDueDate = it },
            onDismiss = { pickTarget = null }
        )
    }

    if (showDeleteConfirm && ev != null) {
        ConfirmDangerDialog(
            title = "Excluir evento?",
            message = "O evento \"${ev.name}\" será excluído e suas tarefas vinculadas serão mantidas sem vínculo.",
            onConfirm = {
                showDeleteConfirm = false
                onDelete(ev.id)
            },
            onDismiss = { showDeleteConfirm = false }
        )
    }
}
